var col = document.querySelector("button");
isBlack=false;
col.addEventListener("click",function(){
    if(isBlack) {
        document.body.style.background = "white";
    }
    else {
        document.body.style.background = "black";
    }
    isBlack = !isBlack;
});