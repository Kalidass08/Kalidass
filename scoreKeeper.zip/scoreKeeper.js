var p1button  = document.querySelector("#p1");
var p2button = document.getElementById("p2");
var span1 = document.querySelector("#s1");
var span2 = document.querySelector("#s2");
var res = document.querySelector("#reset");
var numinput = document.querySelector("input");
var par = document.querySelector("p span");
p1Score = 0;
p2Score = 0;
var gameOver = false;
var winningScore = 5;
p1button.addEventListener("click",function() {
    if(!gameOver) {
        p1Score++;
    }
    if(p1Score === winningScore) {
        span1.classList.add("winner");
        gameOver = true;
    }
    span1.textContent=p1Score;
});

p2button.addEventListener("click",function() {
    if(!gameOver) {
        p2Score++;
    }
    if(p2Score === winningScore) {
        span2.classList.add("winner");
        gameOver = true;
    }
    span2.textContent=p2Score;
});

res.addEventListener("click",function(){
   reset();
});

function reset() {
    p1Score = 0;
    p2Score = 0;
    span1.textContent = 0;
    span2.textContent = 0;
    span1.classList.remove("winner");
    span2.classList.remove("winner");
    gameOver = false;
}


numinput.addEventListener("change",function() {
    par.textContent = this.value;
    winningScore = parseInt(this.value);
});
